# vest-game
2048 贪吃蛇 小游戏 

参考游戏链接  https://www.crazygames.com/game/cubes-2048-io


美术 效果图 使用 pxCook 工具打开  可以看效果图和 界面信息

export namespace AudioClipName {

    export namespace music {
        export const bgm = 'bgm';
    }

    export namespace effect {
        export const click = 'click';
        export const error = 'error';
    }
}


export default class EventName {

    static score: string = 'score';
    static best_score: string = 'best_score';
    static level: string = 'level';
    static roomid: string = 'roomid';
    static isinit: string = 'isinit';

}
